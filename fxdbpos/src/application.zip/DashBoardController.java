package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class DashBoardController {

    @FXML
    private Label lbl_username;
    
    public void userName(String userName) {
    	lbl_username.setText(userName);
    }

}
